<?php
$name = $_POST ['name'];
$visitor_email = $_POST ['email'];
$message = $_POST ['message'];

$email_from = 'alfred@chinesepod.com';

$email_subject = "New Form Submission - TAIPEI STUDIOS";

$email_body = "User Name: $name.\n".
                "User Email: $visitor_email.\n".
                 "User Message: $message.\n";



 $to = "alfred@chinesepod.com";

 $headers = "From: $email_from \r\n";

 $headers = "Reply-to: $visitor_email \r\n";


 mail($to,$email_subject,$email_body,$headers);

 header("location: index.html");

?>